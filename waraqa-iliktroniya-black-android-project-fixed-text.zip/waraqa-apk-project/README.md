# ورقة إلكترونية — Android APK

هذا المشروع جاهز للبناء على GitHub Actions. بعد رفعه إلى GitHub، افتح تبويب **Actions** ثم شغّل **Build APK**. سيظهر APK كـ Artifact باسم `Waraqa-Electronique-debug`.
