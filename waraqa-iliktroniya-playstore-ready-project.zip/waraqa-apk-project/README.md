# ورقة إلكترونية — Play Store

Project prepared for Google Play: target/compile SDK 36 and release AAB build.

The release build expects these GitHub Actions secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.
